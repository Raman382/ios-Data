//
//  ViewController.swift
//  PodInstall
//
//  Created by trainee on 18/12/19.
//  Copyright © 2019 trainee. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    
    
    
    @IBOutlet weak var tblVwData:UITableView!
    
    var dict = [NSMutableDictionary]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let urlStr = "https://jsonplaceholder.typicode.com/users"
        Alamofire.request(urlStr).responseJSON{(data) in
            if let getDict = data.result.value{
                self.dict = getDict as! [NSDictionary] as! [NSMutableDictionary]
                self.tblVwData.reloadData()
            }else{
                print("Error")
            }
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableVC", for : indexPath) as! TableVC
        
        cell.lblId.text = ("\(dict[indexPath.row]["id"] ?? "error")")
        cell.lblName.text = ("\(dict[indexPath.row]["name"] ?? "error")")
        cell.lblUsername.text = ("\(dict[indexPath.row]["username"] ?? "error")")
        cell.lblEmail.text = ("\(dict[indexPath.row]["email"] ?? "error")")
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(dict[indexPath.row]["id"] as Any )
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 800
    }
    
}
