//
//  TableVC.swift
//  PodInstall
//
//  Created by trainee on 18/12/19.
//  Copyright © 2019 trainee. All rights reserved.
//

import UIKit
class TableVC: UITableViewCell {


    @IBOutlet weak var lblId: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
