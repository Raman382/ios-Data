//
//  ViewController.swift
//  CollectionView1
//
//  Created by trainee on 08/11/19.
//  Copyright © 2019 trainee. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource{
    
    @IBOutlet weak var collVw: UICollectionView!
    
    let arrFood = ["Burger","Fruits","Pizza","Vegetables"]
    let arrFoodImages : [UIImage] = [#imageLiteral(resourceName: "Burger"),#imageLiteral(resourceName: "Fruits"),#imageLiteral(resourceName: "Pizza"),#imageLiteral(resourceName: "Vegetables")]

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrFood.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for:indexPath) as! CollectionViewCell
        cell.imgVw.image = arrFoodImages[indexPath.item]
        cell.lblTxt.text = arrFood[indexPath.row]
        return cell
    }
    
}

