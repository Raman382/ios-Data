//
//  CollectionViewCell.swift
//  CollectionView1
//
//  Created by trainee on 08/11/19.
//  Copyright © 2019 trainee. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgVw: UIImageView!
    @IBOutlet weak var lblTxt: UILabel!
    
}
