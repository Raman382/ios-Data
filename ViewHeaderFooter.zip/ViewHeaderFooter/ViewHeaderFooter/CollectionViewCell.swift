//
//  CollectionViewCell.swift
//  ViewHeaderFooter
//
//  Created by trainee on 30/10/19.
//  Copyright © 2019 trainee. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
}
